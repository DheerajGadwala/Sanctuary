package sanctuarymanager;

/**
 * Squirrel is a species in the primate genus.
 */
public class Squirrel extends PrimateGenus {
  /**
   * Creates an object of squirrel.
   */
  public Squirrel() {
    super("Squirrel");
  }
}
