package sanctuarymanager;

/**
 * Guereza is a species in the primate genus.
 */
public class Guereza extends PrimateGenus {
  /**
   * creates a Guereza object.
   */
  public Guereza() {
    super("Guereza");
  }
}
