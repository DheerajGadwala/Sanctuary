package sanctuarymanager;

/**
 * Drill is a species in the primate genus.
 */
public class Drill extends PrimateGenus {
  /**
   * creates a Drill object.
   */
  public Drill() {
    super("Drill");
  }
}
