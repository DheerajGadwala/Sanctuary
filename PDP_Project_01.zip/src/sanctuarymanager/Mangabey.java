package sanctuarymanager;

/**
 * Mangabey is a species in the primate genus.
 */
public class Mangabey extends PrimateGenus {
  /**
   * creates a Mangabey object.
   */
  public Mangabey() {
    super("Mangabey");
  }
}
