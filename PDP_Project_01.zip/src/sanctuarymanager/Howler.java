package sanctuarymanager;

/**
 * Howler is a species in the primate genus.
 */
public class Howler extends PrimateGenus {
  /**
   * Creates a howler object.
   */
  public Howler() {
    super("Howler");
  }
}
