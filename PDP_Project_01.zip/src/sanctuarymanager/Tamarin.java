package sanctuarymanager;

/**
 * Tamarin is a species in the primate genus.
 */
public class Tamarin extends PrimateGenus {
  /**
   * Creates an object of tamarin.
   */
  public Tamarin() {
    super("Tamarin");
  }
}
