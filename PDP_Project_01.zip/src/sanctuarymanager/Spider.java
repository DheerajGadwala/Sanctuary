package sanctuarymanager;

/**
 * Spider is a species in the primate genus.
 */
public class Spider extends PrimateGenus {
  /**
   * Creates an object of spider.
   */
  public Spider() {
    super("Spider");
  }
}
