package sanctuarymanager;

/**
 * Saki is a species in the primate genus.
 */
public class Saki extends PrimateGenus {
  /**
   * Creates a saki object.
   */
  public Saki() {
    super("Saki");
  }
}
